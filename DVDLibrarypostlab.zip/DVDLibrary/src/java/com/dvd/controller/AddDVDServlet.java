/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dvd.controller;

import javax.servlet.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.LinkedList;
import com.dvd.model.DVDItem;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author amirah hasya
 */

public class AddDVDServlet extends HttpServlet 
{
    
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
   }
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest( request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest( request, response);
    
    PrintWriter out = response.getWriter();    
    List errorMsgs = new LinkedList();

    try
    {
      String title = request.getParameter("title");
      String year = request.getParameter("year");////did the user type in a genre?
      String genre = request.getParameter("newGenre");
      //if not, use the drop-down list value
      if( (genre == null ) || (genre.trim().length()==0) )
      {
         genre = request.getParameter("genre");
      }
      
      //Form verification
      DVDItem item = new DVDItem(title,year,genre);//business logic
      if( title == null || (title.trim().length() == 0 ))
      {
          errorMsgs.add("Please enter the DVD title: ");
      }
      if( year == null || (year.trim().length() == 0 ))
      {
          errorMsgs.add("Please enter the year of release for the DVD: ");
      }
      else if( !year.trim().matches("\\d\\d\\d\\d"))
      {
          errorMsgs.add("Please enter a valid year: ");
      }
      if( !errorMsgs.isEmpty())
      {
          request.setAttribute("errorMsgs", errorMsgs);
          RequestDispatcher view = request.getRequestDispatcher("/AddDVDFormServlet");
          view.forward(request, response);
          return;
          
      }
      // out.println("SUCCESS: added DVD titled'" + item.getTitle() + " ");
      // out.close();
      request.setAttribute("dvdItem", item);//store the item on the request-scope
      RequestDispatcher view = request.getRequestDispatcher("/success.view");//dispatch the Success View
      view.forward(request, response);
      return;
    
   }
   catch (RuntimeException e)//handle any unexpected expectations
   {
     errorMsgs.add("An unexpected error: " + e.getMessage());
     request.setAttribute("errorMsgs", errorMsgs);
     RequestDispatcher view = request.getRequestDispatcher("/error.view");
     view.forward(request, response);
     
   }
  }
  @Override
  public String getServletInfo()
  {
      return "Short description";
  }// </editor-fold>
}

