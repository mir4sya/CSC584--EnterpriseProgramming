/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dvd.view;

import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author amirah hasya
 */
public class AddDVDFormServlet extends HttpServlet
{
    private String genres = null; //add a field 
    
    public void init()throws ServletException //add a method
    {
       genres = "Sci-fi, drama, comedy";
    }
     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
     throws ServletException, IOException {
         
     response.setContentType("text/html");
     
     try (PrintWriter out = response.getWriter())
     {
         //Within the init method, retrieve the genre-list initialization parameter.
         //You should split method on this value to the genres instance variable. 
         //The delimiter of the string is a comma
         String[] arrOfStr = genres.split(",");
         out.println("<!DOCTYPE html>");
         out.println("<html>");
         out.println("<head>");
         out.println("<title>Servlet: AddDVDFormServlet</title>");            
         out.println("</head>");
         out.println("<body>");
         out.println("<form method='post' action='Add_dvd.do'>"); //action & method
         out.println("<h1>Add DVD</h1>");
         
         //For each form field, repopulate the field using the request parameter data
         //display the title field
         String title = request.getParameter("title"); 
         out.println("Title:<input type='text' name='title'");
         if(title == null) 
         {
            title = "";
         }
         out.println("value = '" + title + "' /> <br/><br/>");
         
         //display the year field
         String year = request.getParameter("year"); 
         out.println("Year:<input type='text' name='year'");
         if(year == null) 
         {
            year = "";
         }
         out.println("value = '" + year + "' /> <br/><br/>");
         
         String genre = request.getParameter("genre");
         //Repopulate the Genre drop-down menu
         out.println(" Genre: <select name='genre'>");
         for ( int i = 0; i < arrOfStr.length; i++ )
         {
             out.print(" <option value='" + arrOfStr[i] + "'");
             if(genre != null && genre.equals(arrOfStr[i])) 
             {
                out.print(" SELECTED");
             }
             out.println("> " + arrOfStr[i] + "</option>");
         }
         out.println(" </select>");
         
         //display the genre field
         String newGenre = request.getParameter("newGenre");
         out.print(" or new genre: <input type='text' name='newGenre' ");
         if(newGenre == null) 
         {
             newGenre = "";
         }
         out.println("value = '" + newGenre + "'/> <br/><br/>");
         
         out.println("<input type='submit' value='Submit'/>");
         out.println("</form>");
         out.println("<h2>Error Report</h2>");
         out.println("<font color='red'>Correct any errors :");
         out.println("<ul>");
         
         //retrieve the errorMsgs attribute from the request-scope
         //errorMsgs attribute is a List object, so we need to import the List interface.
         List errorMsgs = (List) request.getAttribute("errorMsgs");
         Iterator items = errorMsgs.iterator();
         while(items.hasNext())
         {
            String message = (String) items.next();
            out.println(" <li>"+ message +"</li>");
         }
         out.println("</ul>");
         out.println("Try again.");
         
         out.println("</body>");
         out.println("</html>");
     }
    }
         
         @Override
         protected void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException
         {
            processRequest(request, response);
         }


         @Override
         protected void doPost(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException 
         {
            processRequest(request, response);
         }

        @Override
        public String getServletInfo() 
        {
            return "Short description";
        }
}
